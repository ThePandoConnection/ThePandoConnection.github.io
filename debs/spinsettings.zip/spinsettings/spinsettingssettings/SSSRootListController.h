#import <Preferences/PSListController.h>

@interface SSSRootListController : PSListController

@end
