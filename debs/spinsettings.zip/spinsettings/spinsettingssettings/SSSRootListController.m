#include "SSSRootListController.h"
#include <spawn.h>
#include <signal.h>

@implementation SSSRootListController

- (NSArray *)specifiers {
	if (!_specifiers) {
		_specifiers = [[self loadSpecifiersFromPlistName:@"Root" target:self] retain];
	}

	return _specifiers;
}

- (void)viewWillAppear:(BOOL)animated {

	[super viewWillAppear:animated];
	UIBarButtonItem *spring = [[[UIBarButtonItem alloc] initWithTitle:@"Respring" style:UIBarButtonItemStyleBordered target:self action:@selector(respringDevice)] autorelease];
	self.navigationItem.rightBarButtonItem = spring;
	[UISwitch appearanceWhenContainedIn:self.class, nil].onTintColor = [UIColor blackColor];

}

- (void)viewWillDisappear:(BOOL)animated {

		[super viewWillDisappear:animated];

}

-(void)save
{
    [self.view endEditing:YES];
}

- (void)respringDevice
{
   UIAlertController *vc = [UIAlertController
   alertControllerWithTitle:@"SpinSettings"
   message:@"Would you like to save and respring ?"
   preferredStyle:UIAlertControllerStyleAlert];

   UIAlertAction* yesButton = [UIAlertAction
   actionWithTitle:@"Respring"
   style:UIAlertActionStyleDefault
   handler:^(UIAlertAction *action)
   {
      pid_t pid;
      int status;
      const char *argv[] = {"killall", "SpringBoard", NULL};
      posix_spawn(&pid, "/usr/bin/killall", NULL, NULL, (char* const*)argv, NULL);
      waitpid(pid, &status, WEXITED);
   }];

   UIAlertAction* noButton = [UIAlertAction
   actionWithTitle:@"Cancel"
   style:UIAlertActionStyleDefault
   handler:^(UIAlertAction *action)
   {

   }];

   [vc addAction:yesButton];
   [vc addAction:noButton];
   UIViewController *rootView = [[UIApplication sharedApplication].keyWindow rootViewController];
   [rootView presentViewController:vc animated:YES completion:nil];

    NSLog(@"stack: %@", [NSThread callStackSymbols]);
}

@end
